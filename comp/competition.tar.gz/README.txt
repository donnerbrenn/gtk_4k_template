#### Competition by Thunder_Burn ####

A 4K exegfx (well, actually it's just around 3K) for Linux x86_64 released on Nova 2020.

Tools used to do this production: KodeLife, vondehi, VS Code + a lot of coffee.

Dependencies:
ibglib2.0-0
libgtk-3-0
libgl

Run it at 1920x1080 - Behaviour in other resolutions is undefined.

Greetings fly out to blackle, unlord, shiz & porocyon, yx, farbrausch, titan, k2, alcatraz, ASD, still, poo-brain, mercury, alcatraz, church of the spinning cube